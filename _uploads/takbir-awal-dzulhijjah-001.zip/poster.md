---
judul: "Takbir Awal Dzulhijjah"
sub_judul: "Collab Dakwah Sunnah : *@an.nashiha_daily*"
kategori: "Dzulhijjah (12)"
kategori_emoji: "🌙"
tags: "dzulhijjah, takbir, takbirmutlaq, takbirmuqoyyad, hariarafah, haritasyriq, ibadah, sunnah"
images: "1.jpg"
tidakpakepdf: "brosur.pdf"
---
<!--cap2-->
Mungkin Ada Yang Belum Tahu

Takbir Awal Dzulhijjah Ada 2:

1. TAKBIR MUTLAQ
Dibaca mulai sejak tanggal 1 Dzulhijjah sampai tanggal 13 Dzulhijjah (yaitu pada saat tenggelamnya matahari pada tanggal 13 tersebut)
Takbir yang dilakukan pada setiap waktu, dalam rumah maupun di pasar-pasar, di mesjid dan tempat-tempat lainnya kecuali yang bukan merupakan tempat untuk dzikir kepada Allah

2. TAKBIR MUQOYYAD
Dimulai sejak selesai sholat shubuh pada hari arafah (tanggal 9 Dzul Hijjah) sampai pada selesai sholat Ashar tanggal 13 Dzul Hijjah pada hari Tasyriq, Dibaca setelah selesai sholat lima waktu
(Syarhul Mumti‘: 165-167/5)

INILAH LAFADZ TAKBIRNYA:

اللَّهُ أَكْبَرُ اللَّهُ أَكْبَرُ اللَّهُ أَكْبَرُ لَا إِلَهَ إِلَّا اللَّهُ وَاللَّهُ أَكْبَرُ اللَّهُ أَكْبَرُ وَلِلَّهِ الْحَمْدُ

ALLAHU AKBAR, ALLAHU AKBAR, ALLAHU AKBAR, LAA ILAHA ILLALLAH, WALLAHU AKBAR, ALLAHU AKBAR, WA LILLAHIL HAMD.

DAN BALASANNYA ADALAH SYURGA
Tidaklah seorang bertahlil, kecuali dia akan mendapatkan kabar gembira. Tidaklah seorang bertakbir, kecuali dia mendapatkan kabar gembira. "Ditanyakan kepada beliau, "Wahai Rasulullah, apakah diberi kabar gembira dengan (balasan) surga?" Beliau menjawab, "Iya."
(HR. ath-Thabrani dalam al-Ausath no. 7943)